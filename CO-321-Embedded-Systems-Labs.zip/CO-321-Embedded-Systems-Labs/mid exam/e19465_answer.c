// -------------------------------------------------------------
// University of Peradeniya - Faculty of Engineering
// Mid-Semester Examination - December 2023
// CO321 Embedded Systems
// -------------------------------------------------------------
// Registration Number: E/19/465
// -------------------------------------------------------------

// Include library files here
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

// Define your global variables here
volatile unsigned char pattern[] = {1, 2, 4, 8, 16, 8, 4, 2};
volatile unsigned char patternCounter = 0;
volatile unsigned char delayCounter = 0;
volatile unsigned char buttonPressed = 0;

// functions used
void delay_knight_rider();
void handle_pb3();

// Main Function
int main(void)
{
    // PB0.PB1,PB2,PB3,PB4 is output
    DDRB = 0b00011111;

    // PD2 is set to take input
    DDRD &= ~(1 << 2);

    // delay function for knight rider pattern
    delay_knight_rider();

    // for Timer0 => set for falling edge ditection
    EICRA |= (1 << ISC01) | (0 << ISC00);

    // enabling global interrupts
    sei();

    // Enabling INT0 interrupt
    EIMSK |= (1 << INT0);

    while (1)
    {
        // suppluy button debounce delay
        _delay_ms(50);

        if (buttonPressed % 2 == 0)
        {
            // once push button release enable the timer overflow interrupt
            // so, khight rider pattern will continue
            TIMSK0 |= (1 << TOIE0);
        }
        else
        {
            // once button pressed again, disable the timer0 overflow interrupt
            // so, knight rider will stop
            TIMSK0 &= ~(1 << TOIE0);

            // checking when stop, PB3 is on
            // if ON, then handle PB3 using fast PWM mode
            if (PINB & (1 << PB3))
            {
                handle_pb3();
            }
        }
    }
    return 0;
}

void delay_knight_rider()
{
    // this function gives 2ms delay
    // loading starting value for counter
    TCNT0 = 131;

    // normal mode
    TCCR0A = 0x00;

    // pre-scaler: 256
    TCCR0B = 0x04;

    // enabling timer overflow interrupt
    TIMSK0 |= (1 << TOIE0);
}

void handle_pb3()
{
    _delay_ms(300);

    // enabling fast PWM mode and non invertion mode
    // WGM21 -> 1, WGM20   ->     ==> fast PWM
    // COM2A1 -> 1, COM2A0 -> 0 ==> non - inverting

    // fast PWM & non-inverting mode
    TCCR2A |= (1 << WGM21) | (1 << WGM20) | (1 << COM2A1);

    // pre-scaler: 256
    TCCR2B = 0x04;

    // run this until button pressed again
    while (1)
    {
        for (int i = 255; i >= 0; i--)
        {

            // while runninng the fast PWM in PB3
            // if another button pressed in came
            // then continue knight rider again
            if (buttonPressed % 2 == 0)
            {
                goto continueKnightRider;
            }

            // OCR2A value decreasing
            // so, supply voltage will decreasing
            // so, Brightness will decrease when i decrease
            OCR2A = i;
            _delay_ms(1000 / 255);
            // (1000/255) * 255 = 1000ms = 1s for off, same for on
        }

        // add delay to cleary see on-off
        _delay_ms(200);

        for (int i = 0; i < 256; i++)
        {
            if (buttonPressed % 2 == 0)
            {
                goto continueKnightRider;
            }

            // OCR2A value increasing
            // so, supply voltage will increasing
            // so, Brightness will decrease when i increase
            OCR2A = i;
            _delay_ms(1000 / 255);
        }
    }
continueKnightRider:
    // when going out from this function
    // disable the fast PWM and non-inverting mode for PB3
    // so, PB3 enable to continue knight rider
    TCCR2A &= ~((1 << WGM21) | (1 << WGM20) | (1 << COM2A1));
    TCCR2B = 0x00;
}

// External Intererupt 0 Service Routine
ISR(INT0_vect)
{
    buttonPressed++;
    if (buttonPressed == 2)
    {
        buttonPressed = 0;
    }
}

// Timer0 Overflow Interrupt Service Routine
ISR(TIMER0_OVF_vect)
{
    delayCounter++;
    // 2ms x 100 = 200ms
    if (delayCounter == 100)
    {
        delayCounter = 0;
        PORTB = pattern[patternCounter];
        patternCounter++;
        if (patternCounter == 8)
        {
            patternCounter = 0;
        }
    }
    delay_knight_rider();
}
